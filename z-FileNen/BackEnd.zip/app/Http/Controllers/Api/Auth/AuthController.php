<?php

namespace App\Http\Controllers\Api\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\LoginRequest;
use App\Http\Requests\Auth\RegisterRequest;
use App\Http\Resources\UserSettingsResource;
use App\Models\User;
use App\Models\UserSetting;
use App\Support\ApiResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class AuthController extends Controller
{
    use ApiResponse;

    public function register(RegisterRequest $request)
    {
        $user = User::create([
            'name' => $request->string('name')->toString(),
            'email' => $request->string('email')->toString(),
            'password' => Hash::make($request->string('password')->toString()),
        ]);

        $settings = UserSetting::create([
            'user_id' => $user->id,
            'display_name' => $user->name,
            'email' => $user->email,
            'avatar_url' => $request->input('avatar_url', ''),
            'theme' => 'dark',
            'grid_size' => 'medium',
            'autoplay_video_preview' => true,
            'confirm_before_delete' => true,
            'default_ratio' => '1:1',
            'auto_open_result' => true,
            'auto_save_prompt' => true,
        ]);

        $token = $user->createToken($request->input('device_name', 'web-' . Str::random(8)))->plainTextToken;

        return $this->success([
            'token' => $token,
            'token_type' => 'Bearer',
            'user' => [
                'id' => $user->id,
                'name' => $user->name,
                'email' => $user->email,
            ],
            'settings' => new UserSettingsResource($settings),
        ], 'Registered', 201);
    }

    public function login(LoginRequest $request)
    {
        $user = User::where('email', $request->string('email')->toString())->with('setting')->first();

        if (! $user || ! Hash::check($request->string('password')->toString(), $user->password)) {
            return $this->error('Invalid credentials', 422, ['email' => ['Email or password is incorrect.']]);
        }

        $token = $user->createToken($request->input('device_name', 'web'))->plainTextToken;

        return $this->success([
            'token' => $token,
            'token_type' => 'Bearer',
            'user' => [
                'id' => $user->id,
                'name' => $user->name,
                'email' => $user->email,
            ],
            'settings' => $user->setting ? new UserSettingsResource($user->setting) : null,
        ], 'Logged in');
    }

    public function me(Request $request)
    {
        $user = $request->user()->load('setting');

        return $this->success([
            'id' => $user->id,
            'name' => $user->name,
            'email' => $user->email,
            'settings' => $user->setting ? new UserSettingsResource($user->setting) : null,
        ]);
    }

    public function logout(Request $request)
    {
        $request->user()?->currentAccessToken()?->delete();

        return $this->success(null, 'Logged out');
    }
}
