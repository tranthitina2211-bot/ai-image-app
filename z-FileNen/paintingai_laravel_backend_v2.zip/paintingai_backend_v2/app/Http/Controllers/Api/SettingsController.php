<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\UpdateSettingsRequest;
use App\Http\Resources\UserSettingsResource;
use App\Models\UserSetting;
use Illuminate\Http\Request;

class SettingsController extends Controller
{
    public function show(Request $request): UserSettingsResource
    {
        $user = $request->user();
        $settings = UserSetting::firstOrCreate(
            ['user_id' => $user->id],
            [
                'display_name' => $user->name,
                'email' => $user->email,
                'avatar_url' => '',
                'theme' => 'dark',
                'grid_size' => 'medium',
                'autoplay_video_preview' => true,
                'confirm_before_delete' => true,
                'default_ratio' => '1:1',
                'auto_open_result' => true,
                'auto_save_prompt' => true,
            ]
        );

        return new UserSettingsResource($settings);
    }

    public function update(UpdateSettingsRequest $request): UserSettingsResource
    {
        $user = $request->user();
        $settings = UserSetting::firstOrCreate(['user_id' => $user->id]);
        $data = $request->validated();

        $settings->fill([
            'display_name' => data_get($data, 'profile.displayName', $settings->display_name),
            'email' => data_get($data, 'profile.email', $settings->email),
            'avatar_url' => data_get($data, 'profile.avatarUrl', $settings->avatar_url),
            'theme' => $data['theme'] ?? $settings->theme,
            'grid_size' => $data['gridSize'] ?? $settings->grid_size,
            'autoplay_video_preview' => $data['autoplayVideoPreview'] ?? $settings->autoplay_video_preview,
            'confirm_before_delete' => $data['confirmBeforeDelete'] ?? $settings->confirm_before_delete,
            'default_ratio' => $data['defaultRatio'] ?? $settings->default_ratio,
            'auto_open_result' => $data['autoOpenResult'] ?? $settings->auto_open_result,
            'auto_save_prompt' => $data['autoSavePrompt'] ?? $settings->auto_save_prompt,
        ]);
        $settings->save();

        return new UserSettingsResource($settings->fresh());
    }
}
