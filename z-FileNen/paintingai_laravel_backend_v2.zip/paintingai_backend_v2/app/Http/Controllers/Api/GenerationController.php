<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\GenerateStoreRequest;
use App\Http\Resources\GenerationJobResource;
use App\Models\GenerationJob;
use App\Models\MediaItem;
use App\Services\Generation\GenerationService;
use Illuminate\Http\Request;

class GenerationController extends Controller
{
    public function __construct(private readonly GenerationService $generationService)
    {
    }

    public function generate(GenerateStoreRequest $request)
    {
        $user = $request->user();
        $job = $this->generationService->createGenerateJob($user, $request->validated());

        return response()->json([
            'jobId' => $job->id,
            'job' => new GenerationJobResource($job->load('mediaItems')),
        ], 201);
    }

    public function variation(Request $request, string $mediaId)
    {
        $user = $request->user();
        $media = MediaItem::query()->where('user_id', $user->id)->findOrFail($mediaId);
        $job = $this->generationService->createDerivedJob($user, $media, 'variation', 'image');
        return response()->json(['jobId' => $job->id, 'job' => new GenerationJobResource($job->load('mediaItems'))], 201);
    }

    public function upscale(Request $request, string $mediaId)
    {
        $user = $request->user();
        $media = MediaItem::query()->where('user_id', $user->id)->findOrFail($mediaId);
        $job = $this->generationService->createDerivedJob($user, $media, 'upscale', $media->type);
        return response()->json(['jobId' => $job->id, 'job' => new GenerationJobResource($job->load('mediaItems'))], 201);
    }

    public function imageToVideo(Request $request, string $mediaId)
    {
        $user = $request->user();
        $media = MediaItem::query()->where('user_id', $user->id)->findOrFail($mediaId);
        $job = $this->generationService->createDerivedJob($user, $media, 'image_to_video', 'video');
        return response()->json(['jobId' => $job->id, 'job' => new GenerationJobResource($job->load('mediaItems'))], 201);
    }

    public function status(Request $request, string $jobId): GenerationJobResource
    {
        $user = $request->user();
        $job = GenerationJob::query()->where('user_id', $user->id)->with('mediaItems')->findOrFail($jobId);
        return new GenerationJobResource($job);
    }

    public function cancel(Request $request, string $jobId): GenerationJobResource
    {
        $user = $request->user();
        $job = GenerationJob::query()->where('user_id', $user->id)->findOrFail($jobId);
        return new GenerationJobResource($this->generationService->cancelJob($job)->load('mediaItems'));
    }
}
