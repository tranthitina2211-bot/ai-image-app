<?php

namespace App\Services\Generation;

use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Http;

class ComfyUiService
{
    public function queuePrompt(string $jobId, string $prompt): array
    {
        $baseUrl = rtrim(config('services.comfyui.base_url', 'http://127.0.0.1:8188'), '/');
        $workflowPath = storage_path('app/comfy/base_workflow.json');

        if (! File::exists($workflowPath)) {
            return [
                'driver' => 'mock',
                'provider_job_id' => null,
            ];
        }

        $workflow = File::get($workflowPath);
        $workflow = str_replace(['{{PROMPT}}', '{{JOB_ID}}'], [$prompt, $jobId], $workflow);

        $response = Http::timeout((int) config('services.comfyui.timeout', 60))
            ->acceptJson()
            ->post($baseUrl . '/prompt', [
                'prompt' => json_decode($workflow, true),
            ]);

        if (! $response->successful()) {
            return [
                'driver' => 'mock',
                'provider_job_id' => null,
                'error' => $response->body(),
            ];
        }

        return [
            'driver' => 'comfyui',
            'provider_job_id' => $response->json('prompt_id'),
        ];
    }

    public function fetchHistory(string $providerJobId): array
    {
        $baseUrl = rtrim(config('services.comfyui.base_url', 'http://127.0.0.1:8188'), '/');
        return Http::timeout((int) config('services.comfyui.timeout', 60))
            ->acceptJson()
            ->get($baseUrl . '/history/' . $providerJobId)
            ->json() ?? [];

    }
}
