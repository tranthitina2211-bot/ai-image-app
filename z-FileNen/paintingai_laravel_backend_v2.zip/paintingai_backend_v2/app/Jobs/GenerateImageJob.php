<?php

namespace App\Jobs;

use App\Events\JobProgressUpdated;
use App\Models\GenerationJob;
use App\Services\Generation\ComfyUiService;
use App\Services\Generation\GenerationService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Storage;

class GenerateImageJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public function __construct(public string $jobId)
    {
    }

    public function handle(ComfyUiService $comfyUiService, GenerationService $generationService): void
    {
        $job = GenerationJob::query()->with('mediaItems', 'stack')->findOrFail($this->jobId);
        if ($job->status === 'cancelled') {
            return;
        }

        $job->update([
            'status' => 'generating',
            'progress' => 5,
            'started_at' => now(),
        ]);
        $job->mediaItems()->update(['status' => 'processing', 'progress' => 5]);
        $generationService->logEvent($job, 'started', 'Worker started processing');
        broadcast(new JobProgressUpdated($job->id, ['status' => 'generating', 'progress' => 5]));

        $provider = $comfyUiService->queuePrompt($job->id, $job->prompt ?? '');
        if (($provider['provider_job_id'] ?? null) !== null) {
            $job->update(['provider_job_id' => $provider['provider_job_id']]);
        }

        foreach ([25, 50, 75, 95] as $progress) {
            sleep(1);
            $job->refresh();
            if ($job->status === 'cancelled') {
                return;
            }

            $job->update(['progress' => $progress]);
            $job->mediaItems()->update(['progress' => $progress]);
            $generationService->logEvent($job, 'progress', 'Progress updated', ['progress' => $progress]);
            broadcast(new JobProgressUpdated($job->id, ['status' => 'generating', 'progress' => $progress]));
        }

        $media = $job->mediaItems()->first();
        $extension = $media->type === 'video' ? 'mp4' : 'jpg';
        $disk = config('filesystems.default', 'public');
        $path = 'generated/' . $media->id . '.' . $extension;
        Storage::disk($disk)->put($path, 'Generated placeholder for job ' . $job->id);

        $url = Storage::disk($disk)->url($path);

        $media->update([
            'url' => $url,
            'storage_disk' => $disk,
            'storage_path' => $path,
            'mime_type' => $media->type === 'video' ? 'video/mp4' : 'image/jpeg',
            'status' => 'success',
            'progress' => 100,
            'generated_at' => now(),
        ]);

        $job->update([
            'status' => 'done',
            'progress' => 100,
            'finished_at' => now(),
        ]);

        $job->stack?->update([
            'cover_media_item_id' => $media->id,
            'item_count' => $job->stack->items()->count(),
            'last_generated_at' => now(),
        ]);

        $generationService->logEvent($job, 'completed', 'Generation completed', ['media_item_id' => $media->id, 'url' => $url]);

        broadcast(new JobProgressUpdated($job->id, [
            'status' => 'done',
            'progress' => 100,
            'image_url' => $url,
            'mediaItemId' => $media->id,
        ]));
    }
}
